<?php
require('fpdf/fpdf.php');
require('fpdf/autoload.php');

use Fpdi\Fpdi;
use Fpdi\PdfReader;


 
$pdf = new FPDI('P','mm',array(178.9,263.31));
$pdf->AddPage();
 
//Set the source PDF file
$pagecount = $pdf->setSourceFile("invoice.pdf");
$tpl = $pdf->importPage(1, PdfReader\PageBoundaries::MEDIA_BOX);
$pdf->useTemplate($tpl);
 
//Add Name for Invoice
$pdf->SetXY(31,37);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 4, "John Doe", 0, 1,'L',1);
 
//Add Company for invoice
$pdf->SetXY(31,42.80);
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 4, "John & Doe Co.", 0, 1,'L',1);
 
//Add Address Line 1 for invoice
$pdf->SetXY(31,47.80);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 3, "23 Areena Plaza, Street 45", 0, 1,'L',1);
 
//Add Address Line 2 for invoice
$pdf->SetXY(31,51.80);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 3, "Old Town, Boston, MA", 0, 1,'L',1);
 
//Add Address Line 3 for invoice
$pdf->SetXY(31,56.80);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 3, "United States", 0, 1,'L',1);
 
//Add Invoice No.
$pdf->SetXY(140,37);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',8);
$pdf->Cell(30, 5, "WPEASY-190726", 0, 1,'L',1);
 
//Add Date for invoice
$pdf->SetXY(140,42.80);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',8);
$pdf->Cell(30, 5, "26 July 2019", 0, 1,'L',1);
     
//Add Product Name for invoice
$pdf->SetXY(11,82);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',9);
$pdf->Cell(80, 6, "WordPress Website Development & Designing", 0, 1,'L',1);
 
//Add Price for Invoice
$pdf->SetXY(146,82);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','',9);
$pdf->Cell(15, 6, "500.00 USD", 0, 1,'L',1);
 
//Add Total Price for Invoice
$pdf->SetXY(146,171.8);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(15, 5, "500.00 USD", 0, 1,'L',1);
 
//Add Total amount payable in Words
$pdf->SetXY(9,185);
$pdf->SetFillColor(255,255,255);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(60, 5, "FIVE HUNDREDS DOLLARS ONLY", 0, 1,'L',1);
 
//destination of dynamically generate pdf. F stands for saving the file.
$pdf->Output("invoice_generated.pdf", "F");